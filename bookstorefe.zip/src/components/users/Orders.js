import React, { Fragment, useEffect, useState } from "react";
import axios from "axios";
import Header from "./Header";
import { baseUrl } from "../constants";
import "./modal.css";

export default function Orders() {
  const [data, setData] = useState([]);


  useEffect(() => {
    getData();
  }, []);

  const getData = () => {    
    const url = `${baseUrl}/api/Cart/GetOrdersList?id=${localStorage.getItem("loggedEmail")}`;
    axios
      .get(url)
      .then((result) => {
        if(result.status === 200)
        {
          setData(result.data)
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <Fragment>
      <Header />
      <br></br>
      <div class="form-group col-md-12">
        <h3>My Orders</h3>
      </div>
      {data ? (
        <table
          className="table stripped table-hover mt-4"
          style={{ backgroundColor: "white", width: "80%", margin: "0 auto" }}>
          <thead className="thead-dark">
            <tr>
              <th scope="col">#</th>
              <th scope="col">Order No</th>
              <th scope="col">Total</th>
              <th scope="col">Order Date</th>
            </tr>
          </thead>
          <tbody>
            {data.map((val, index) => {
              return (
                <tr key={index}>
                  <th scope="row">{index + 1}</th>
                  <td>
                    {val.orderNo}
                  </td>
                  <td>{val.orderTotal}</td>
                  <td>{val.createdOn.split('T')[0]}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      ) : (
        "No data found"
      )}   
    </Fragment>
  );
}
