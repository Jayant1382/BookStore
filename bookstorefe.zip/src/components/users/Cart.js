import React, { Fragment, useEffect, useState } from "react";
import axios from "axios";
import Header from "./Header";
import { baseUrl } from "../constants";

export default function Cart() {
  const [data, setData] = useState([]);

  useEffect(() => {
    getData();
  }, []);

  const getData = () => {    
    const url = `${baseUrl}/api/Cart/GetCartItems?id=${localStorage.getItem("loggedEmail")}`;
    axios
      .get(url)
      .then((result) => {
        if(result.status === 200)
        {
          setData(result.data);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handlePlaceOrder =(e)=>{
    e.preventDefault();
    const data = {
      UserId: localStorage.getItem("loggedEmail")
    };
    const url = `${baseUrl}/api/Cart/PlaceOrder?UserId=${localStorage.getItem("loggedEmail")}`;
    axios
      .post(url, data)
      .then((result) => {
        if(result.status === 200)
        {
          setData([]);
          alert('Order has been placed.');
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }

  return (
    <Fragment>
      <Header />
      <br></br>
      <div class="form-group col-md-12">
        <h3>Cart items</h3>
        {data && data.length ?
        <button className="btn btn-primary" onClick={(e)=> handlePlaceOrder(e)}>
          Place Order
        </button>
        : ''}
      </div>
      <div
        style={{
          backgroundColor: "white",
          width: "80%",
          margin: "0 auto",
          borderRadius: "11px",
        }}
      >
        <div className="card-deck">
          {data && data.length > 0
            ? data.map((val, index) => {
              return(
                <div key={index} class="col-md-3" style={{marginBottom:"21px"}}>
                <div class="card">
                 
                  <div class="card-body">
                  <h4 class="card-title">Product : {val.name}</h4>
                  <hr/>
                        <h4 class="card-title">Price : {val.unitPrice}</h4>              
                        <hr/>
                    <h4 class="card-title">Quantity : {val.quantity}</h4>          
                    {/* <a href="#" class="btn btn-primary">
                      Remove
                    </a>      */}
                  </div>
                </div>
              </div>
              )
            })
            : "No item to display. Kindly add..."}
        </div>
      </div>
    </Fragment>
  );
}
