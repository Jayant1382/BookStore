import React from  'react';
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom';

//Admin Pages
import AdminDashboard from './admin/AdminDashboard';
import BooksManagement from './admin/BooksManagement';

// Login / Registration
import Login from './Login';
import Registration from './Registration';

//User Pages
import ProductsDisplay from './users/ProductsDisplay';
import Cart from './users/Cart';
import Dashboard from './users/Dashboard';
import Orders from './users/Orders';

export default function RouterPage(){
    
    return(
        <Router>
            <Routes>
                {/* Login - Registration */}
                <Route exact path='/' element={ <Login /> } />
                <Route path='/registration' element={ <Registration /> } />
                
                {/* Admin Pages */}
                <Route path='/admindashboard' element={ <AdminDashboard /> } />
                <Route path='/booksmanagement' element={ <BooksManagement /> } />

                {/* Users Pages */}
                <Route path='/dashboard' element={ <Dashboard /> } />                
                <Route path='/myorders' element={ <Orders /> } />
                <Route path='/cart' element={ <Cart /> } />
                <Route path='/products' element={ <ProductsDisplay /> } />
                
            </Routes>
        </Router>
    )
}