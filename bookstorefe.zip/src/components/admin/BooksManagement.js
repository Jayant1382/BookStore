import React, { Fragment, useEffect, useState } from "react";
import axios from "axios";
import AdminHeader from "./AdminHeader";
import { baseUrl } from "../constants";

export default function BooksManagement() {
  const [data, setData] = useState([]);
  const [bookId, setBookId] = useState("");
  const [name, setName] = useState("");
  const [unitPrice, setUnitPrice] = useState("");
  const [author, setAuthor] = useState("");
  const [addUpdateFlag, setAddUpdateFlag] = useState(true);

  const AddBook = async (e) => {
    e.preventDefault();
    let error = '';
    if (name === '')
      error += 'Name ,';
    if (author === '')
      error += 'Author ,';
    if (unitPrice === '')
      error += 'UnitPrice ';

    if (error === '') {

      const currentDate = new Date();
      const data = {
        Name: name,
        Author: author,
        UnitPrice: unitPrice,
        IsActive: 1,
        CreatedBy: localStorage.getItem("loggedEmail"),
        CreatedOn: currentDate
      };
      const url = `${baseUrl}/api/Books`;
      axios
        .post(url, data)
        .then((result) => {
          debugger
          if (result.status === 201) {
            getData();
            Clear();
          }
        })
        .catch((error) => {
          console.log(error);
        });
    }
    else {
      error += ' are mandatory fields.'
      alert(error);
    }
  };

  const Clear = () => {
    setName("");
    setUnitPrice("");
    setAuthor("");
  };

  useEffect(() => {
    getData();
  }, []);

  const getData = () => {    
    const url = `${baseUrl}/api/Books`;
    axios
      .get(url)
      .then((result) => {
        if(result.status === 200)
        {
          setData(result.data);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const deleteBook = (e, id) => {
    debugger;
    e.preventDefault();    
    const url = `${baseUrl}/api/Books/${id}`;
    axios
      .delete(url)
      .then((result) => {
        if(result.status === 200)
        {
          getData();
          alert('Record deleted.');
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const editBook = (e, id) => {
    e.preventDefault();
    setAddUpdateFlag(false);    
    const url = `${baseUrl}/api/Books/${id}`;
    axios
      .get(url)
      .then((result) => {
        if(result.status === 200)
        {        
          setBookId(id);
          setName(result.data.name);
          setAuthor(result.data.author);
          setUnitPrice(result.data.unitPrice);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const updateBook = (e) => {
    let error = '';
    if (name === '')
      error += 'Name ,';
    if (author === '')
      error += 'Author ,';
    if (unitPrice === '')
      error += 'UnitPrice ';

    if (error === '') {

      //const currentDate = new Date();
      const data = {
        Id : bookId,
        Name: name,
        Author: author,
        UnitPrice: unitPrice,
        IsActive: 1,
        CreatedBy: localStorage.getItem("loggedEmail"),
        //CreatedOn: currentDate
      };
      const url = `${baseUrl}/api/Books`;
      axios
        .put(url, data)
        .then((result) => {
          debugger
          if (result.status === 200) {
            getData();
            Clear();
            alert('Record updated.');
          }
        })
        .catch((error) => {
          console.log(error);
        });
    }
    else {
      error += ' are mandatory fields.'
      alert(error);
    }
  };

  return (
    <Fragment>
      <AdminHeader />
      <br></br>
      <form>
        <div
          class="form-row"
          style={{ width: "80%", backgroundColor: "white", margin: " auto" }}
        >
          <div class="form-group col-md-12">
            <h3>Books Management</h3>
          </div>
          <div className="form-group col-md-6">
            <input
              type="text"
              onChange={(e) => setName(e.target.value)}
              placeholder="Name"
              className="form-control"
              required
              value={name}
            />
          </div>
          <div className="form-group col-md-6">
            <input
              type="text"
              onChange={(e) => setAuthor(e.target.value)}
              placeholder="Author"
              className="form-control"
              required
              value={author}
            />
          </div>

          <div className="form-group col-md-6">
            <input
              type="number"
              className="form-control"
              id="validationTextarea"
              placeholder="UnitPrice"
              onChange={(e) => setUnitPrice(e.target.value)}
              required
              value={unitPrice}
            ></input>
          </div>
          <div className="form-group col-md-6">

            {addUpdateFlag ? (
              <button
                className="btn btn-primary"
                style={{ width: "150px", float: "left" }}
                onClick={(e) => AddBook(e)}
              >
                Add
              </button>
            ) : (
              <button
                className="btn btn-primary"
                style={{ width: "150px", float: "left" }}
                onClick={(e) => updateBook(e)}
              >
                Update
              </button>
            )}
            <button
              className="btn btn-danger"
              style={{ width: "150px" }}
              onClick={(e) => Clear(e)}
            >
              Reset
            </button>
          </div>
        </div>
      </form>
      {data ? (
        <table
          className="table stripped table-hover mt-4"
          style={{ backgroundColor: "white", width: "80%", margin: "0 auto" }}
        >
          <thead className="thead-dark">
            <tr>
              <th scope="col">#</th>
              <th scope="col">Name</th>
              <th scope="col">Author</th>
              <th scope="col">UnitPrice</th>
              <th scope="col">CreatedOn</th>
              <th scope="col" colSpan="2">
                Action
              </th>
            </tr>
          </thead>
          <tbody>
            {data.map((val, index) => {
              return (
                <tr key={index}>
                  <td scope="row">{index + 1}</td>
                  <td>{val.name}</td>
                  <td>{val.author}</td>
                  <td>{val.unitPrice}</td>
                  <td>{val.createdOn.split('T')[0]}</td>                 
                  <td>
                    <button onClick={(e) => editBook(e, val.id)}>
                      Edit
                    </button>{" "}
                 |{" "}
                    <button onClick={(e) => deleteBook(e, val.id)}>
                      Delete
                    </button>{" "}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      ) : (
        "No data found"
      )}
    </Fragment>
  );
}
