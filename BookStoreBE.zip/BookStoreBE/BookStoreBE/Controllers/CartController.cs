﻿using BookStoreBE.Models;
using BookStoreBE.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Transactions;

namespace BookStoreBE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly ICartRepository _cartRepository;
        public CartController(ICartRepository cartRepository)
        {
            _cartRepository = cartRepository;
        }

        [HttpGet]
        [Route("GetCartItems")]
        public IActionResult GetCartItems(int id)
        {
            var cart = _cartRepository.GetById(id);
            return new OkObjectResult(cart);
        }

        [HttpGet]
        [Route("GetOrdersList")]
        public IActionResult GetOrdersList(int id)
        {
            var orders = _cartRepository.OrderList(id);
            return new OkObjectResult(orders);
        }

        [HttpPost]
        [Route("AddToCart")]
        public IActionResult AddToCart([FromBody] Cart cart)
        {
            using (var scope = new TransactionScope())
            {
                _cartRepository.AddToCart(cart);
                scope.Complete();
                return new OkResult();
            }
        }

        [HttpDelete]
        [Route("RemoveFromCart")]
        public IActionResult RemoveFromCart(int id)
        {
            using (var scope = new TransactionScope())
            {
                _cartRepository.RemoveFromCart(id);
                scope.Complete();
                return new OkResult();
            }
        }

        [HttpPost]
        [Route("PlaceOrder")]
        public IActionResult PlaceOrder(int UserId)
        {
            using (var scope = new TransactionScope())
            {
                _cartRepository.PlaceOrder(UserId);
                scope.Complete();
                return new OkResult();
            }
        }

    }
}
