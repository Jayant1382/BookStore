﻿using BookStoreBE.Models;
using BookStoreBE.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Transactions;

namespace BookStoreBE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {

        private readonly IUserRepository _userRepository;
        public UsersController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        [HttpPost]
        [Route("Login")]
        public IActionResult Login([FromBody] Users user)
        {
            if (user != null)
            {
                Users objuser = _userRepository.Login(user);
                if (objuser != null)
                {                    
                    return new OkObjectResult(objuser);
                }
                else
                    return new NoContentResult();
            }
            return new NoContentResult();
        }

        [HttpPost]
        [Route("Registration")]
        public IActionResult Registration([FromBody] Users user)
        {
            using (var scope = new TransactionScope())
            {
                _userRepository.Registration(user);
                scope.Complete();
                return new OkObjectResult(user);
            }
        }
    }
}
